package cpsc2150.banking;

/**
 * Created by rexroao on 4/12/19.
 */
public class MortgageView implements IMortgageView {
}
